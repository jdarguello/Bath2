import NewGame;

public class Connect4 {
    public static void main(String[] args){
		NewGame.newSession();
	}
}
